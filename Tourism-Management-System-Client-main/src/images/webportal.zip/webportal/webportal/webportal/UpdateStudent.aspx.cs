﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace webportal
{
    public partial class UpdateStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string connectionString = ConfigurationManager.ConnectionStrings["mydb"].ConnectionString;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT DeptName FROM Department"; // Adjust the query as per your database schema

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        connection.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string deptName = reader["DeptName"].ToString();
                                ddlDeptName.Items.Add(new ListItem(deptName));
                            }
                        }
                    }
                }

                // Add a default item for selection
                ddlDeptName.Items.Insert(0, new ListItem("Select Department", ""));
            }
        }

        protected void btnFilter_Click(object sender, EventArgs e)
        {
            // Get the selected department and semester
            string selectedDept = ddlDeptName.SelectedValue;
            string selectedSemester = ddlSemester.SelectedValue;

            // Check if both department and semester are selected
            if (!string.IsNullOrEmpty(selectedDept) && !string.IsNullOrEmpty(selectedSemester))
            {
                // Construct the SQL query to fetch students based on department and semester
                string connectionString = ConfigurationManager.ConnectionStrings["mydb"].ConnectionString;
                string query = "SELECT StuName, Semester FROM Student WHERE S_DeptId = @DeptId AND Semester = @Semester";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        // Retrieve the DeptId from the selected department
                        int deptId = GetDeptId(selectedDept);

                        // Add parameters to the SQL query to prevent SQL injection
                        cmd.Parameters.AddWithValue("@DeptId", deptId);
                        cmd.Parameters.AddWithValue("@Semester", selectedSemester);

                        connection.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            // Check if there are any students matching the filter criteria
                            if (reader.HasRows)
                            {
                                // Create a DataTable to hold the results
                                DataTable dt = new DataTable();
                                dt.Load(reader);

                                // Bind the DataTable to the GridView to display matching students
                                gvStudents.DataSource = dt;
                                gvStudents.DataBind();

                                // Hide the student details panel
                                pnlStudentDetails.Visible = false;
                            }
                            else
                            {
                                // If no matching students found, hide the GridView and student details panel
                                gvStudents.DataSource = null;
                                gvStudents.DataBind();
                                pnlStudentDetails.Visible = false;
                            }
                        }
                    }
                }
            }
        }

        // Helper function to retrieve S_DeptId based on DeptName
        private int GetDeptId(string deptName)
        {
            int deptId = 0;

            string connectionString = ConfigurationManager.ConnectionStrings["mydb"].ConnectionString;
            string query = "SELECT DeptId FROM Department WHERE DeptName = @DeptName";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@DeptName", deptName);
                    connection.Open();

                    object result = cmd.ExecuteScalar();

                    if (result != null)
                    {
                        deptId = Convert.ToInt32(result);
                    }
                }
            }

            return deptId;
        }




    }
}
